class Transaction < ApplicationRecord
end