module FurnituresHelper
end
