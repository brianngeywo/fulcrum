require 'test_helper'

class FurnitureTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
